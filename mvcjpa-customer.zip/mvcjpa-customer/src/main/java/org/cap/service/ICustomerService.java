package org.cap.service;

import org.cap.entities.Customer;

import java.util.List;

public interface ICustomerService {

    Customer findById(int id);

    Customer add(Customer customer);
    Customer update(Customer customer);


    List<Customer> fetchAll();

    boolean remove(int id);
}
